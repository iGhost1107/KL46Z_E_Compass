#include "MKL46Z4.h"
#include <stdbool.h>
#include "fsl_debug_console.h"
#include "fsl_i2c.h"
#include "pin_mux.h"
#include "board.h"
#include "lcd.h"
#include <math.h>

#define MAG3110_I2C_ADDR 0x0E
//////////////////////////// Jack added
#define PORTC_D_IRQ_NBR (IRQn_Type) 31 // Define the interrupt number for PORTC and PORTD

void initLed(); // Function declaration for initializing LEDs
void initSW(); // Function declaration for initializing switches
// Function declaration for the interrupt handler
void PORTC_PORTD_IRQHandler(void);
int32_t volatile systemState = 0; // Variable to hold the system state
int32_t system_stop = 0; // Define constant for system stop state
int32_t system_running = 1; // Define constant for system running state

void initLed(){
    // Initialize RED LED on PTE29
    SIM->SCGC5 |= (1<<13); // Enable clock to PORTE
    PORTE->PCR[29] = (1<<8); // Set PTE29 as GPIO
    PTE->PDDR |= (1<<29); // Set PTE29 as output
    
    // Initialize GREEN LED on PTD5
    SIM->SCGC5 |= (1<<12); // Enable clock to PORTD
    PORTD->PCR[5] = (1<<8); // Set PTD5 as GPIO
    PTD->PDDR |= (1<<5); // Set PTD5 as output
}

void initSW(){
    SIM->SCGC5 |= (1<<11); // Enable clock to PORTC

    // Initialize SW1 on PTC3
    PORTC->PCR[3] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK; // Set PTC3 as GPIO with pull-up resistor
    PTC->PDDR &= ~(uint32_t)(1u<<3); // Set PTC3 as input
    PORTC->PCR[3] |= PORT_PCR_IRQC(0xA); // Enable interrupt on falling edge for PTC3
    
    // Initialize SW2 on PTC12
    PORTC->PCR[12] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK; // Set PTC12 as GPIO with pull-up resistor
    PTC->PDDR &= ~(uint32_t)(1u<<12); // Set PTC12 as input
    PORTC->PCR[12] |= PORT_PCR_IRQC(0xA); // Enable interrupt on falling edge for PTC12
    
    NVIC_ClearPendingIRQ(PORTC_D_IRQ_NBR); // Clear any pending interrupts
    NVIC_EnableIRQ(PORTC_D_IRQ_NBR); // Enable interrupts for PORTC and PORTD
}

void PORTC_PORTD_IRQHandler(){
    uint32_t i = 0;
	for(i=0; i<1000; i++);
	if((PTC->PDIR & (1<<3)) == 0){
		if(systemState == system_running){
			systemState = system_stop;
			/*while(1){
			PTD->PCOR |= (1<<5);
			PTE->PTOR |= (1<<29);
			Delay(2000);
			}*/
			PORTC->PCR[3] |= PORT_PCR_ISF_MASK;
		}
		else{
			systemState = system_running;
			PORTC->PCR[3] |= PORT_PCR_ISF_MASK;
		}
	}
		
	if ((PTC->PDIR & (1<<12)) == 0) { 
        NVIC_SystemReset();
        PORTC->PCR[3] |= PORT_PCR_ISF_MASK;
    }
}

uint32_t volatile msTicks = 0; // Variable to count milliseconds

void init_Systick_interrupt(){
    SysTick->LOAD = SystemCoreClock/1000; // Configure the SysTick to generate interrupt every 1 ms
    // Select Core Clock, Enable SysTick, Enable Interrupt
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_ENABLE_Msk;
    
}

void SysTick_Handler (void) { // SysTick interrupt handler
    msTicks++; // Increment counter
}

void Delay (uint32_t TICK) {
    while (msTicks < TICK); // Wait until the desired delay is reached
    msTicks = 0; // Reset counter
}

void NVIC_SetPriorityLevels(void) {
    NVIC_SetPriority(SysTick_IRQn, 1); // Set priority for SysTick interrupt
    NVIC_SetPriority(PORTC_PORTD_IRQn, 2); // Set priority for GPIO interrupts
}
////////////////////////////////////////////// Jack added
void init_i2c(void);
void send_i2c(uint8_t device_addr, uint8_t reg_addr, uint8_t value);
void read_i2c(uint8_t device_addr, uint8_t reg_addr, uint8_t *rxBuff, uint32_t rxSize);

volatile bool isReadyToGetData;

int main(void)
{
	////////// Jack added
	initLed(); // Initialize LEDs
  initSW(); // Initialize switches
  init_Systick_interrupt(); // Initialize SysTick interrupt
	///////// Jack added
	init_i2c();
	send_i2c(MAG3110_I2C_ADDR, 0x10, 0x01);
	send_i2c(MAG3110_I2C_ADDR, 0x11, 0x80);

	SIM->SCGC5 |= SIM_SCGC5_PORTD_MASK;
	PORTD->PCR[1] = PORT_PCR_MUX(1);
	PTD->PDDR &= ~(1 << 1);
	
	LCD_Init();

	//PRINTF("Init MAG3110 Complete\n\r");
	int32_t state;
	
	uint8_t rxBuff[6];
	while (1)
	{ 
    state = systemState;
		if(state == system_running){
		PTE->PSOR |= (1<<29);
		PTD->PTOR |= (1<<5);
		Delay(500);
			
		
		if((PTD->PDIR & (1<<1)) == 0) continue;
		
		read_i2c(MAG3110_I2C_ADDR, 1, rxBuff, 6);
		
		int16_t x = ((int16_t)((rxBuff[0] * 256U) | rxBuff[1]));
		int16_t y = ((int16_t)((rxBuff[2] * 256U) | rxBuff[3]));
		int16_t z = ((int16_t)((rxBuff[4] * 256U) | rxBuff[5]));
			
		///////////////////////
		
		
			
			
		
			
			
			
			
			
			
			///////////////////////
		int8_t t = atan2(y,x) * 180/3.14;
		uint8_t m;
	
		if(t<0){
					LCD_DisplayDecimal(t+360);
		}
		

		//PRINTF("status_reg = 0x%x , x = %5d , y = %5d , z = %5d \r\n", PTD->PDIR & (1<<1), x, y, z);
		
		LCD_DisplayDecimal(t);
		}
		if(state == system_stop){
		LCD_StopDisplay();
		PTD->PSOR |= (1<<5);
		PTE->PTOR |= (1<<29);
		Delay(1000);
		}
	}
}

void init_i2c()
{
	i2c_master_config_t masterConfig;
	BOARD_InitPins();
	BOARD_BootClockRUN();
	BOARD_InitDebugConsole();
	BOARD_I2C_ConfigurePins();

	I2C_MasterGetDefaultConfig(&masterConfig);
	masterConfig.baudRate_Bps = 100000U;
	I2C_MasterInit(I2C0, &masterConfig, CLOCK_GetFreq(I2C0_CLK_SRC));
}

void send_i2c(uint8_t device_addr, uint8_t reg_addr, uint8_t value)
{
	i2c_master_transfer_t masterXfer;

	masterXfer.slaveAddress = device_addr;
	masterXfer.direction = kI2C_Write;
	masterXfer.subaddress = (uint32_t)reg_addr;
	masterXfer.subaddressSize = 1;
	masterXfer.data = &value;
	masterXfer.dataSize = 1;
	masterXfer.flags = kI2C_TransferDefaultFlag;

	I2C_MasterTransferBlocking(I2C0, &masterXfer);
}

void read_i2c(uint8_t device_addr, uint8_t reg_addr, uint8_t *rxBuff, uint32_t rxSize)
{
	i2c_master_transfer_t masterXfer;

	masterXfer.slaveAddress = device_addr;
	masterXfer.direction = kI2C_Read;
	masterXfer.subaddress = (uint32_t)reg_addr;
	masterXfer.subaddressSize = 1;
	masterXfer.data = rxBuff;
	masterXfer.dataSize = rxSize;
	masterXfer.flags = kI2C_TransferDefaultFlag;

	I2C_MasterTransferBlocking(I2C0, &masterXfer);
}
